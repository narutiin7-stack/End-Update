# The End Update – Bosses (porte do Better on Bedrock → Forge 1.20.1)

Addon em **código-fonte Java** que traz 5 chefes do Better on Bedrock: **Willager, Enchantaegis, Flender,
Piroclasto Blindado e Samurai Murcho**, com olhos, estruturas e a nova receita do Olho do Fim.
⚠️ **Nunca foi compilado nem testado no jogo** (o ambiente onde foi gerado não tem Minecraft/Forge nem internet).
Só a sintaxe dos 18 arquivos Java foi verificada. Espere corrigir alguns erros de compilação e ajustar valores.

## Como compilar
1. Baixe o **Forge MDK 1.20.1 (47.x)** em files.minecraftforge.net e use o **JDK 17**.
2. Copie `gradlew`, `gradlew.bat` e a pasta `gradle/` do MDK para esta pasta.
3. Rode `./gradlew build` → o jar sai em `build/libs/the_end_update_bosses-1.0.0.jar`.
4. Coloque o jar em `mods/` **junto** com o TheEndUpdate. (Para testar direto: `./gradlew runClient`.)
Dica: se o Gradle reclamar do `settings.gradle`, apague o bloco `plugins { ... foojay ... }`.

## Por que é um mod separado e não dentro do TheEndUpdate.jar
Eu só tinha o `.jar` compilado do seu mod (sem o código-fonte original). Um mod separado se instala ao lado
dele, não corre o risco de quebrar o que já funciona e se compila sozinho. A receita do Olho do Fim é um datapack
que sobrescreve a receita do vanilla, então funciona igual.

## O que foi portado
| Item | Como ficou |
|---|---|
| 5 olhos | `willager_eye`, `enchantaegis_eye`, `flender_eye`, `shielded_pyroclast_eye`, `withered_samurai_eye` (texturas originais). Cada chefe dropa só o seu olho. |
| Receita | `data/minecraft/recipes/ender_eye.json` **substitui** a receita vanilla (pérola + pó de blaze): 1 pérola do Ender + os 5 olhos → **16 Olhos do Fim**. |
| Estruturas | Convertidas dos `.mcstructure` para `.nbt` do Java (blocos novos do Bedrock trocados por equivalentes vanilla, ver abaixo). |
| Modelos/texturas | Os `.geo.json` viraram código Java (`BossModelDefs`, gerado). Texturas e sons originais. |
| Barra de vida | Barra roxa/vermelha padrão do Java (as texturas custom de barra do Bedrock não existem no Java). |

### Onde cada chefe aparece
- **Willager** – `willager_arena` (planícies/florestas/floresta de bétulas; a cada ~76 chunks). Acorda ao abrir o baú central.
- **Enchantaegis** – `enchantaegis_tower` (torre de 54 blocos, mesmos biomas; ~124 chunks). Nasce a 23 blocos de altura.
- **Flender** – `flender_tower` (topo da torre de quartzo; ~50 chunks).
- **Piroclasto Blindado** – `pyroclast_arena` (Nether, y 36–70, arena de Blackstone).
- **Samurai Murcho** – `samurai_castle` (Nether, castelo de Blackstone).
Para testar sem procurar: `/place structure the_end_update_bosses:flender_tower` (idem para os outros).
Também: `/summon the_end_update_bosses:willager` etc.

## Mecânicas (fiéis aos JSON do Bedrock)
- **Willager** 450/666/888 de vida (fácil/normal/difícil), foge a 8 blocos, presas em linha (16/22 blocos), anéis expansivos,
  bombas de alvo (impacto 3, explosão 2 sem quebrar blocos), 8 iscas voadoras (somem se alguma for atingida),
  modo de cura após 25 s até ser atingido.
- **Enchantaegis** 210 de vida, imune a fogo; só leva dano enquanto lança magia (preparo/caminhada absorvem golpes);
  anéis/linhas/presas no alvo, livros encantados + feixe, zumbis encantados, raios, rugido ao ser ferido (dano 12).
- **Flender** 250 de vida, voa; bola de fogo grande, rajada de 16 bolas, 4 phantoms, mergulho (dano 15, ×4 de dano
  recebido no corpo a corpo durante o mergulho); projéteis causam só 20%.
- **Piroclasto Blindado** 400 de vida; corpo a corpo (6), 6 bolas de fogo, feixe de 15 chamas, aura de fogo
  (raio 7, dano 6), escudos infernais (impacto 25).
- **Samurai Murcho** 350 de vida; golpe de espada (6) e giro (1.7× de velocidade).

## O que é APROXIMAÇÃO (leia!)
- **Animações**: o Bedrock usa animações Molang, que não existem no Java. Escrevi animações procedurais simples
  (`BossAnimators.java`): olhar, andar, braços levantados, asas, giro. Se algum osso ficar torto, ajuste ali.
- **Rotações dos ossos** (gerador): usei a conversão (-x, -y, z). Se algo vier de cabeça pra baixo, inverta no gerador.
- **Samurai**: o JSON enviado não traz o gatilho das caveiras de Wither nem do feixe de chamas (só as entidades
  auxiliares). Fiz disparar a cada ~10 s. O escudo magma ("healing_with_shield") **não** foi implementado.
- **Flender**: as entidades `lich` (chão) e `fire_place` do pacote **não foram ligadas** (não achei o gatilho da fase 2).
- **Piroclasto**: o "escudo" é um ataque de projéteis; não há escudo que reduza dano.
- **Alvo do Willager** (disco no chão) é só partícula; o modelo `willager_target` não foi usado.
- Valores de dano por tick do Bedrock (feixes) foram convertidos para dano a cada 10 ticks.
- Hitboxes escolhidas por mim a partir do tamanho dos modelos (ver `ModEntities`).
- Blocos do Bedrock sem equivalente no 1.20.1 foram trocados (carvalho-pálido→bétula, tuff 1.21→tijolo de pedra,
  resina→terracota laranja, blocos custom do BoB→vanilla parecido). Baús têm loot convertido só com itens vanilla.
- Spawners/blocos de comando do Bedrock viraram **ar**; os chefes entram como entidades dentro da estrutura.
- As estruturas do Nether incluem ar (escavam a rocha). Podem ficar parcialmente embutidas na lava/terra.
- Itens de loot dos chefes do Bedrock que não eram olhos (chapéu, estátua, runas…) foram **removidos**, como pedido.
- Heads-up: o `purpur_golem` do próprio TheEndUpdate ainda dropa `minecraft:ender_eye` — é outro jeito de obter olhos.

## Arquivos
- `src/main/java/...` – código (registro, 6 entidades + projétil, cliente, eventos).
- `src/main/resources/data/the_end_update_bosses/` – estruturas `.nbt`, worldgen, loot tables.
- `src/main/resources/data/minecraft/recipes/ender_eye.json` – receita nova.
- `src/main/resources/assets/the_end_update_bosses/` – texturas, sons, lang (en_us / pt_br).
