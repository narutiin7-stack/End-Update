package br.theendupdate.bosses.registry;

import br.theendupdate.bosses.EndUpdateBosses;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Os 5 olhos de chefe. Cada um e dropado pelo seu chefe e usado na receita do Olho do Fim. */
public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, EndUpdateBosses.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EndUpdateBosses.MODID);

    private static RegistryObject<Item> eye(String id) {
        return ITEMS.register(id, () -> new Item(new Item.Properties().rarity(Rarity.EPIC)));
    }

    public static final RegistryObject<Item> WILLAGER_EYE = eye("willager_eye");
    public static final RegistryObject<Item> ENCHANTAEGIS_EYE = eye("enchantaegis_eye");
    public static final RegistryObject<Item> FLENDER_EYE = eye("flender_eye");
    public static final RegistryObject<Item> SHIELDED_PYROCLAST_EYE = eye("shielded_pyroclast_eye");
    public static final RegistryObject<Item> WITHERED_SAMURAI_EYE = eye("withered_samurai_eye");

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup." + EndUpdateBosses.MODID))
            .icon(() -> WILLAGER_EYE.get().getDefaultInstance())
            .displayItems((params, out) -> {
                out.accept(WILLAGER_EYE.get());
                out.accept(ENCHANTAEGIS_EYE.get());
                out.accept(FLENDER_EYE.get());
                out.accept(SHIELDED_PYROCLAST_EYE.get());
                out.accept(WITHERED_SAMURAI_EYE.get());
            }).build());

    private ModItems() {}
}
