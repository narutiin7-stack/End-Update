package br.theendupdate.bosses.registry;

import br.theendupdate.bosses.EndUpdateBosses;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, EndUpdateBosses.MODID);

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(EndUpdateBosses.MODID, name)));
    }

    public static final RegistryObject<SoundEvent> ENCHANTAEGIS_AMBIENT = reg("entity.enchantaegis.ambient");
    public static final RegistryObject<SoundEvent> ENCHANTAEGIS_HURT = reg("entity.enchantaegis.hurt");
    public static final RegistryObject<SoundEvent> ENCHANTAEGIS_DEATH = reg("entity.enchantaegis.death");
    public static final RegistryObject<SoundEvent> ENCHANTAEGIS_CAST = reg("entity.enchantaegis.cast");
    public static final RegistryObject<SoundEvent> FLENDER_AMBIENT = reg("entity.flender.ambient");
    public static final RegistryObject<SoundEvent> FLENDER_HURT = reg("entity.flender.hurt");
    public static final RegistryObject<SoundEvent> FLENDER_DEATH = reg("entity.flender.death");
    public static final RegistryObject<SoundEvent> PYROCLAST_AMBIENT = reg("entity.shielded_pyroclast.ambient");
    public static final RegistryObject<SoundEvent> PYROCLAST_HURT = reg("entity.shielded_pyroclast.hurt");
    public static final RegistryObject<SoundEvent> PYROCLAST_DEATH = reg("entity.shielded_pyroclast.death");
    public static final RegistryObject<SoundEvent> PYROCLAST_FIRE_AURA = reg("entity.shielded_pyroclast.fire_aura");
    public static final RegistryObject<SoundEvent> PYROCLAST_SHIELD = reg("entity.shielded_pyroclast.shield");
    public static final RegistryObject<SoundEvent> SAMURAI_AMBIENT = reg("entity.withered_samurai.ambient");
    public static final RegistryObject<SoundEvent> SAMURAI_HURT = reg("entity.withered_samurai.hurt");
    public static final RegistryObject<SoundEvent> SAMURAI_DEATH = reg("entity.withered_samurai.death");
    public static final RegistryObject<SoundEvent> SAMURAI_SHOOT = reg("entity.withered_samurai.shoot");
    public static final RegistryObject<SoundEvent> SAMURAI_BLAST = reg("entity.withered_samurai.blast");
    public static final RegistryObject<SoundEvent> SAMURAI_SHIELD = reg("entity.withered_samurai.shield");

    private ModSounds() {}
}
