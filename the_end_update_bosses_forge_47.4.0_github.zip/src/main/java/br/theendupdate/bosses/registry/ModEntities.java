package br.theendupdate.bosses.registry;

import br.theendupdate.bosses.EndUpdateBosses;
import br.theendupdate.bosses.entity.*;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, EndUpdateBosses.MODID);

    public static final RegistryObject<EntityType<WillagerBoss>> WILLAGER = ENTITIES.register("willager", () ->
            EntityType.Builder.of(WillagerBoss::new, MobCategory.MONSTER).sized(0.9F, 2.85F).clientTrackingRange(10).build("willager"));
    public static final RegistryObject<EntityType<WillagerClone>> WILLAGER_CLONE = ENTITIES.register("willager_clone", () ->
            EntityType.Builder.of(WillagerClone::new, MobCategory.MONSTER).sized(0.9F, 2.85F).clientTrackingRange(10).build("willager_clone"));
    public static final RegistryObject<EntityType<EnchantaegisBoss>> ENCHANTAEGIS = ENTITIES.register("enchantaegis", () ->
            EntityType.Builder.of(EnchantaegisBoss::new, MobCategory.MONSTER).sized(0.8F, 2.6F).fireImmune().clientTrackingRange(10).build("enchantaegis"));
    public static final RegistryObject<EntityType<FlenderBoss>> FLENDER = ENTITIES.register("flender", () ->
            EntityType.Builder.of(FlenderBoss::new, MobCategory.MONSTER).sized(3.0F, 3.0F).clientTrackingRange(12).build("flender"));
    public static final RegistryObject<EntityType<PyroclastBoss>> SHIELDED_PYROCLAST = ENTITIES.register("shielded_pyroclast", () ->
            EntityType.Builder.of(PyroclastBoss::new, MobCategory.MONSTER).sized(1.3F, 3.1F).fireImmune().clientTrackingRange(10).build("shielded_pyroclast"));
    public static final RegistryObject<EntityType<SamuraiBoss>> WITHERED_SAMURAI = ENTITIES.register("withered_samurai", () ->
            EntityType.Builder.of(SamuraiBoss::new, MobCategory.MONSTER).sized(1.2F, 4.3F).fireImmune().clientTrackingRange(10).build("withered_samurai"));
    public static final RegistryObject<EntityType<BossProjectile>> BOSS_PROJECTILE = ENTITIES.register("boss_projectile", () ->
            EntityType.Builder.<BossProjectile>of(BossProjectile::new, MobCategory.MISC).sized(0.4F, 0.4F).clientTrackingRange(4).updateInterval(10).build("boss_projectile"));

    private ModEntities() {}
}
