package br.theendupdate.bosses.entity;

import br.theendupdate.bosses.registry.ModEntities;
import br.theendupdate.bosses.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Piroclasto Blindado (entidade "inferior" no Bedrock). 400 de vida, imune a fogo e queda; leva dano na agua.
 * Perto (<2 blocos) bate com 6 de dano. Longe sorteia a cada 6 s: rajada de 6 bolas de fogo, feixe de chamas
 * (15 chamas numa linha de 16 blocos), aura de fogo (carrega 1.2 s e empurra tudo num raio de 7, dano 6)
 * ou escudos infernais (impacto 25, 1.4 s de vida).
 */
public class PyroclastBoss extends BossMob {
    private int auraCharge = 0;

    public PyroclastBoss(EntityType<? extends PyroclastBoss> t, Level l) {
        super(t, l, BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_6, 10);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 400.0).add(Attributes.MOVEMENT_SPEED, 0.23)
                .add(Attributes.ATTACK_DAMAGE, 6.0).add(Attributes.FOLLOW_RANGE, 48.0);
    }

    @Override public boolean fireImmune() { return true; }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.0D, false));
        goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 16.0F));
        goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (src.is(DamageTypeTags.IS_FALL)) return false;
        return super.hurt(src, amount);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (isInWaterOrBubble() && tickCount % 20 == 0) hurt(damageSources().drown(), 1.0F);
        LivingEntity t = getTarget();
        if (auraCharge > 0 && --auraCharge == 0) aura();
        if (t == null || !t.isAlive() || auraCharge > 0) return;
        if (distanceToSqr(t) < 4.0) return;                         // modo corpo a corpo (MeleeAttackGoal)
        if (attackCooldown <= 0 && hasLineOfSight(t)) attack(t);
    }

    private void attack(LivingEntity t) {
        attackCooldown = 120;
        switch (random.nextInt(4)) {
            case 0, 1 -> {                                           // rajada de 6 bolas de fogo pequenas
                setState(1);
                for (int i = 0; i < 6; i++) schedule(i * 5, () -> {
                    if (getTarget() == null) return;
                    BossProjectile p = new BossProjectile(ModEntities.BOSS_PROJECTILE.get(), level(), this)
                            .configure(Items.FIRE_CHARGE, 5.0F, 0.0F, true, 0.0F, 0);
                    Vec3 d = getTarget().getEyePosition().subtract(getEyePosition()).normalize();
                    p.setPos(getX(), getEyeY() - 0.3, getZ()); p.shoot(d.x, d.y, d.z, 1.2F, 6.0F);
                    level().addFreshEntity(p);
                });
                schedule(40, () -> setState(0));
            }
            case 2 -> {                                              // feixe de chamas
                setState(2);
                Vec3 me = position(); float yaw = yawTo(me, t.position()); double rad = Math.toRadians(yaw + 90);
                for (int i = 1; i <= 15; i++) {
                    final Vec3 p = me.add(Math.cos(rad) * i * 16.0 / 15, 0, Math.sin(rad) * i * 16.0 / 15);
                    schedule(i * 2, () -> flameZone(p, 6));
                }
                schedule(60, () -> setState(0));
            }
            default -> {                                             // aura de fogo / escudos
                if (random.nextBoolean()) { setState(3); auraCharge = 24; getNavigation().stop(); }
                else shields(t);
            }
        }
    }

    private void flameZone(Vec3 p, int repeats) {
        particles(ParticleTypes.FLAME, p.add(0, 0.3, 0), 12, 0.5);
        areaDamage(p, 1.2, 5.0F, 4);
        if (repeats > 0) schedule(10, () -> flameZone(p, repeats - 1));
    }

    private void aura() {
        playSound(ModSounds.PYROCLAST_FIRE_AURA.get(), 3.0F, 1.0F);
        particles(ParticleTypes.LAVA, position().add(0, 1, 0), 60, 3);
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(7), x -> x != this)) {
            Vec3 dir = e.position().subtract(position()).normalize();
            e.hurt(damageSources().mobAttack(this), 6.0F);
            e.setSecondsOnFire(4);
            e.setDeltaMovement(dir.x * 2.0, 0.7, dir.z * 2.0); e.hurtMarked = true;
        }
        schedule(20, () -> setState(0));
    }

    private void shields(LivingEntity t) {
        playSound(ModSounds.PYROCLAST_SHIELD.get(), 3.0F, 1.0F);
        setState(4);
        for (int i = -1; i <= 1; i++) {
            BossProjectile p = new BossProjectile(ModEntities.BOSS_PROJECTILE.get(), level(), this)
                    .configure(Items.SHIELD, 25.0F, 1.0F, false, 0.0F, 0).life(28);
            Vec3 d = t.getEyePosition().subtract(getEyePosition()).normalize().yRot((float) Math.toRadians(i * 14));
            p.setPos(getX(), getEyeY(), getZ()); p.shoot(d.x, d.y, d.z, 1.1F, 0.0F);
            level().addFreshEntity(p);
        }
        schedule(30, () -> setState(0));
    }

    @Override protected SoundEvent getAmbientSound() { return ModSounds.PYROCLAST_AMBIENT.get(); }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return ModSounds.PYROCLAST_HURT.get(); }
    @Override protected SoundEvent getDeathSound() { return ModSounds.PYROCLAST_DEATH.get(); }
}
