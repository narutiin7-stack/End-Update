package br.theendupdate.bosses.entity;

import java.util.List;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import br.theendupdate.bosses.registry.ModEntities;

/**
 * Willager (Better on Bedrock). Vida: 450/666/888 (facil/normal/dificil). Foge do jogador (8 blocos) e ataca com presas
 * (aneis, linhas), bombas de alvo e iscas voadoras. Depois de 25 s atacando entra em "modo de cura" ate ser atingido.
 */
public class WillagerBoss extends BossMob {
    private boolean healing = false;
    private int attackTicks = 0;
    private int cloneCooldown = 600;

    public WillagerBoss(EntityType<? extends WillagerBoss> t, Level l) {
        super(t, l, BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS, 3000);
        double hp = byDifficulty(l, 450, 666, 888);
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(hp);
        setHealth((float) hp);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 666.0).add(Attributes.MOVEMENT_SPEED, 0.5)
                .add(Attributes.ATTACK_DAMAGE, 4.0).add(Attributes.FOLLOW_RANGE, 64.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(3, new AvoidEntityGoal<>(this, Player.class, 8.0F, 0.6D, 1.0D));
        goalSelector.addGoal(8, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        goalSelector.addGoal(9, new LookAtPlayerGoal(this, Player.class, 3.0F, 1.0F));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (healing && src.getEntity() != null) { healing = false; attackTicks = 0; setState(0); }
        return super.hurt(src, amount);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        LivingEntity t = getTarget();
        if (healing) {
            setState(2);
            if (tickCount % 20 == 0) heal(getMaxHealth() * 0.01F);
            return;
        }
        if (t == null || !t.isAlive()) return;
        attackTicks++;
        if (cloneCooldown > 0) cloneCooldown--;
        if (attackTicks > 500) { healing = true; return; }       // "healing_mode_till_hit" (timer de 25 s)
        if (attackCooldown <= 0) attack(t);
    }

    private void attack(LivingEntity t) {
        double d = distanceTo(t);
        Vec3 me = position(), tp = t.position();
        float yaw = yawTo(me, tp);
        int roll = random.nextInt(d >= 3 ? 27 : 14);
        setState(1);
        schedule(30, () -> setState(0));
        if (cloneCooldown <= 0 && random.nextInt(8) == 0) { spawnClones(t); cloneCooldown = 1200; attackCooldown = 60; return; }
        if (roll < 8) {                                             // linha de presas (16 presas / 22 blocos)
            fangLine(me, yaw, 16, 22, 14, 1, getY() - 4, getY() + 2); attackCooldown = 42;
        } else if (roll < 11) {                                     // aneis expansivos (raios 0.5 .. 5.5)
            for (int w = 0; w < 3; w++) for (int i = 0; i < 6; i++) {
                final double r = 0.5 + i; final int dly = 14 + w * 14 + i * 2;
                schedule(0, () -> fangRing(position(), r, 15, dly));
            }
            attackCooldown = 63;
        } else if (roll < 19) {                                     // duas presas coladas (defesa corpo a corpo)
            fangRing(me, 1.5, 2, 12); fangLine(me, yaw, 2, 3, 12, 1, getY() - 4, getY() + 2); attackCooldown = 28;
        } else {                                                    // bombas de alvo ao redor do jogador
            for (int i = 0; i < 3; i++) bombAt(tp.add((random.nextDouble() - .5) * 6, 0, (random.nextDouble() - .5) * 6));
            attackCooldown = 45;
        }
    }

    /** "willager_target": marca o chao e, 1.1 s depois, deixa cair a bomba (impacto 3, explosao 2, sem quebrar blocos). */
    protected void bombAt(Vec3 pos) {
        particles(ParticleTypes.WITCH, pos.add(0, 0.2, 0), 18, 0.8);
        schedule(22, () -> {
            BossProjectile p = new BossProjectile(ModEntities.BOSS_PROJECTILE.get(), level(), this)
                    .configure(Items.ENDER_PEARL, 3.0F, 2.0F, false, 0.15F, 0).life(60);
            p.setPos(pos.x, pos.y + 7, pos.z);
            p.setDeltaMovement(0, -0.3, 0);
            level().addFreshEntity(p);
        });
    }

    /** 8 iscas voadoras em circulo (raio 4). Qualquer isca atingida faz todas sumirem. */
    private void spawnClones(LivingEntity t) {
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            WillagerClone c = ModEntities.WILLAGER_CLONE.get().create(level());
            if (c == null) continue;
            c.setOwnerId(getUUID());
            c.moveTo(getX() + Math.cos(a) * 4, getY() + 1, getZ() + Math.sin(a) * 4);
            level().addFreshEntity(c);
        }
        particles(ParticleTypes.POOF, position().add(0, 1, 0), 40, 3);
    }

    public void despawnClones() {
        List<WillagerClone> list = level().getEntitiesOfClass(WillagerClone.class, getBoundingBox().inflate(128));
        for (WillagerClone c : list) if (getUUID().equals(c.getOwnerId())) c.discard();
    }

    @Override
    public void die(DamageSource s) { despawnClones(); super.die(s); }
}
