package br.theendupdate.bosses.entity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.projectile.EvokerFangs;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;

/** Base dos 5 chefes: barra de vida, agendador de ataques e utilitarios (presas, raios, areas de dano). */
public abstract class BossMob extends Monster {
    protected final ServerBossEvent bossEvent;
    private final List<Pending> pending = new ArrayList<>();
    protected int attackCooldown = 40;
    /** Estado de animacao sincronizado com o cliente (0 = parado; cada chefe define os seus). */
    private static final EntityDataAccessor<Integer> DATA_STATE = SynchedEntityData.defineId(BossMob.class, EntityDataSerializers.INT);
    public int getState() { return entityData.get(DATA_STATE); }
    public void setState(int s) { entityData.set(DATA_STATE, s); }
    @Override protected void defineSynchedData() { super.defineSynchedData(); entityData.define(DATA_STATE, 0); }

    private static final class Pending {
        int delay; final Runnable run;
        Pending(int d, Runnable r) { delay = d; run = r; }
    }

    protected BossMob(EntityType<? extends BossMob> type, Level level, BossEvent.BossBarColor color, BossEvent.BossBarOverlay overlay, int xp) {
        super(type, level);
        this.bossEvent = new ServerBossEvent(this.getDisplayName(), color, overlay);
        this.xpReward = xp;
        this.setPersistenceRequired();
    }

    /** Executa {@code r} apos {@code ticks} ticks (somente no servidor). */
    protected void schedule(int ticks, Runnable r) { pending.add(new Pending(Math.max(0, ticks), r)); }

    protected void clearScheduled() { pending.clear(); }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide) {
            for (Iterator<Pending> it = pending.iterator(); it.hasNext();) {
                Pending p = it.next();
                if (p.delay-- <= 0) { it.remove(); p.run.run(); }
            }
            if (attackCooldown > 0) attackCooldown--;
        }
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossEvent.setProgress(getHealth() / getMaxHealth());
    }

    @Override public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); bossEvent.addPlayer(p); }
    @Override public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); bossEvent.removePlayer(p); }
    @Override public void setCustomName(Component name) { super.setCustomName(name); bossEvent.setName(getDisplayName()); }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean canChangeDimensions() { return false; }

    // ---------- utilitarios de ataque ----------

    /** Uma presa de Evoker no chao mais proximo de (x,z). */
    protected void fang(double x, double z, double minY, double maxY, float yaw, int delay) {
        BlockPos pos = BlockPos.containing(x, maxY, z);
        boolean found = false; double extra = 0;
        do {
            BlockPos below = pos.below();
            BlockState bs = level().getBlockState(below);
            if (bs.isFaceSturdy(level(), below, Direction.UP)) {
                if (!level().isEmptyBlock(pos)) {
                    VoxelShape shape = level().getBlockState(pos).getCollisionShape(level(), pos);
                    if (!shape.isEmpty()) extra = shape.max(Direction.Axis.Y);
                }
                found = true; break;
            }
            pos = pos.below();
        } while (pos.getY() >= Mth.floor(minY) - 1);
        if (found) level().addFreshEntity(new EvokerFangs(level(), x, pos.getY() + extra, z, yaw, delay, this));
    }

    /** Linha de presas a partir de {@code from} na direcao {@code yawDeg}. */
    protected void fangLine(Vec3 from, float yawDeg, int count, double length, int baseDelay, int perDelay, double minY, double maxY) {
        double rad = Math.toRadians(yawDeg + 90.0F);
        for (int i = 0; i < count; i++) {
            double d = length * (i + 1) / count;
            fang(from.x + Math.cos(rad) * d, from.z + Math.sin(rad) * d, minY, maxY, (float) rad, baseDelay + perDelay * i);
        }
    }

    /** Anel de presas ao redor de {@code c}. */
    protected void fangRing(Vec3 c, double radius, int count, int delay) {
        for (int i = 0; i < count; i++) {
            double a = i * (Math.PI * 2.0 / count);
            fang(c.x + Math.cos(a) * radius, c.z + Math.sin(a) * radius, c.y - 2, c.y + 2, (float) a, delay);
        }
    }

    protected void lightningAt(Vec3 p) {
        if (level() instanceof ServerLevel sl) {
            var bolt = net.minecraft.world.entity.EntityType.LIGHTNING_BOLT.create(sl);
            if (bolt != null) { bolt.moveTo(p.x, p.y, p.z); sl.addFreshEntity(bolt); }
        }
    }

    /** Dano em area instantaneo (usado por feixes, auras e explosoes magicas). */
    protected void areaDamage(Vec3 c, double radius, float damage, int fireSeconds) {
        AABB box = new AABB(c.x - radius, c.y - 1, c.z - radius, c.x + radius, c.y + 2.5, c.z + radius);
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, box, t -> t != this && !(t instanceof BossMob))) {
            e.hurt(damageSources().mobAttack(this), damage);
            if (fireSeconds > 0) e.setSecondsOnFire(fireSeconds);
        }
    }

    protected void particles(ParticleOptions type, Vec3 p, int n, double spread) {
        if (level() instanceof ServerLevel sl) sl.sendParticles(type, p.x, p.y, p.z, n, spread, spread, spread, 0.02);
    }

    protected float yawTo(Vec3 from, Vec3 to) {
        return (float) (Math.toDegrees(Math.atan2(to.z - from.z, to.x - from.x)) - 90.0);
    }

    /** Vida base por dificuldade (usado pelo Willager). */
    protected static double byDifficulty(Level l, double easy, double normal, double hard) {
        return switch (l.getDifficulty()) { case EASY, PEACEFUL -> easy; case NORMAL -> normal; case HARD -> hard; };
    }
}
