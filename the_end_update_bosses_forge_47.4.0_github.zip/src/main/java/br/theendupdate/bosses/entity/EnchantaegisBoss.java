package br.theendupdate.bosses.entity;

import br.theendupdate.bosses.registry.ModEntities;
import br.theendupdate.bosses.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Enchantaegis. 210 de vida, imune a fogo. Alterna: PREPARO (3 s, parado e imune) -> um ataque (~5 s, vulneravel) ou
 * CAMINHADA (imune). Ataques: aneis de presas, linha de presas, presas ao redor do alvo, livros encantados + feixe,
 * zumbis encantados e raios. Ao ser ferido solta um rugido que empurra quem esta perto (dano 12).
 */
public class EnchantaegisBoss extends BossMob {
    private static final int PREPARE = 1, WALK = 2, ATTACK = 3;
    private int phase = PREPARE, phaseTicks = 0, roarCooldown = 0;

    public EnchantaegisBoss(EntityType<? extends EnchantaegisBoss> t, Level l) {
        super(t, l, BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.NOTCHED_6, 1500);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 210.0).add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.ATTACK_DAMAGE, 6.0).add(Attributes.FOLLOW_RANGE, 48.0).add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override public boolean fireImmune() { return true; }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, false) {
            @Override public boolean canUse() { return phase == WALK && super.canUse(); }
        });
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 1.0D) {
            @Override public boolean canUse() { return phase != PREPARE && super.canUse(); }
        });
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        goalSelector.addGoal(6, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    /** So recebe dano de ataques enquanto esta lancando magia (PREPARO e CAMINHADA absorvem os golpes). */
    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (phase != ATTACK && src.getEntity() != null) {
            level().playSound(null, blockPosition(), SoundEvents.ANVIL_PLACE, SoundSource.HOSTILE, 0.5F, 1.4F);
            return false;
        }
        boolean r = super.hurt(src, amount);
        if (r && src.getEntity() instanceof LivingEntity && roarCooldown <= 0 && distanceTo(src.getEntity()) < 6) {
            roarCooldown = 100; roar();
        }
        return r;
    }

    private void roar() {
        setState(4);
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(6), x -> x != this && !(x instanceof Zombie))) {
            Vec3 dir = e.position().subtract(position()).normalize();
            e.hurt(damageSources().mobAttack(this), 12.0F);
            e.setDeltaMovement(dir.x * 1.6, 0.6, dir.z * 1.6); e.hurtMarked = true;
        }
        particles(ParticleTypes.EXPLOSION, position().add(0, 1, 0), 6, 1.5);
        schedule(10, () -> setState(0));
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (roarCooldown > 0) roarCooldown--;
        phaseTicks++;
        LivingEntity t = getTarget();
        if (phase == PREPARE) {
            getNavigation().stop();
            if (phaseTicks > 60) next(t);
        } else if (phase == WALK && phaseTicks > 100) {
            phase = PREPARE; phaseTicks = 0; setState(1);
        } else if (phase == ATTACK && phaseTicks > 100) {
            phase = PREPARE; phaseTicks = 0; setState(1);
        }
        if (phase == PREPARE) particles(ParticleTypes.ENCHANT, position().add(0, 2, 0), 3, 0.6);
    }

    private void next(LivingEntity t) {
        phaseTicks = 0;
        if (t == null) { phase = WALK; setState(0); return; }
        int pick = random.nextInt(9);
        if (pick < 2) { phase = WALK; setState(0); return; }       // "noVariant": anda ate o alvo, imune
        phase = ATTACK; setState(2);
        playSound(ModSounds.ENCHANTAEGIS_CAST.get(), 2.0F, 1.0F);
        Vec3 me = position(), tp = t.position(); float yaw = yawTo(me, tp);
        switch (pick) {
            case 2 -> { for (int r = 1; r <= 7; r++) { final int rr = r; schedule(rr * 5, () -> fangRing(position(), rr, 4 + rr * 3, 12)); } }
            case 3 -> { for (int i = 0; i < 4; i++) { final int k = i; schedule(k * 20, () -> { if (getTarget() != null) fangLine(position(), yawTo(position(), getTarget().position()), 32, 16, 8, 0, getY() - 4, getY() + 2); }); } }
            case 4 -> { for (int r = 7; r >= 4; r--) { final int rr = r; schedule((7 - rr) * 12, () -> { if (getTarget() != null) fangRing(getTarget().position(), rr, 16, 14); }); } }
            case 5, 6 -> books(t);
            case 7 -> minions();
            default -> { for (int i = 0; i < 3; i++) schedule(i * 25, () -> { if (getTarget() != null) lightningAt(getTarget().position()); }); }
        }
    }

    /** Livros encantados (impacto 5) + feixe magico no alvo (3 de dano num raio de 4 apos 0.7 s). */
    private void books(LivingEntity t) {
        for (int i = 0; i < 3; i++) schedule(i * 15, () -> {
            if (getTarget() == null) return;
            BossProjectile p = new BossProjectile(ModEntities.BOSS_PROJECTILE.get(), level(), this).configure(Items.ENCHANTED_BOOK, 5.0F, 0.0F, false, 0.01F, 0);
            Vec3 d = getTarget().getEyePosition().subtract(getEyePosition()).normalize();
            p.setPos(getX(), getEyeY(), getZ()); p.shoot(d.x, d.y, d.z, 1.5F, 1.0F);
            level().addFreshEntity(p);
        });
        for (int i = 0; i < 4; i++) schedule(10 + i * 20, () -> {
            if (getTarget() == null) return;
            Vec3 c = getTarget().position();
            particles(ParticleTypes.ENCHANT, c.add(0, 0.3, 0), 25, 1.5);
            schedule(14, () -> { particles(ParticleTypes.EXPLOSION, c, 3, 1.0); areaDamage(c, 4, 3.0F, 0); });
        });
    }

    /** Zumbis encantados (maximo 6 vivos por perto). */
    private void minions() {
        int near = level().getEntitiesOfClass(Zombie.class, getBoundingBox().inflate(32), z -> z.getTags().contains("enchantaegis_minion")).size();
        for (int i = 0; i < 2 && near + i < 6; i++) {
            Zombie z = EntityType.ZOMBIE.create(level());
            if (z == null) continue;
            z.moveTo(getX() + (random.nextDouble() - .5) * 8, getY(), getZ() + (random.nextDouble() - .5) * 8);
            ItemStack sword = new ItemStack(Items.IRON_SWORD); sword.enchant(Enchantments.SHARPNESS, 2);
            ItemStack chest = new ItemStack(Items.IRON_CHESTPLATE); chest.enchant(Enchantments.PROTECTION, 2);
            z.setItemSlot(EquipmentSlot.MAINHAND, sword); z.setItemSlot(EquipmentSlot.CHEST, chest);
            z.addTag("enchantaegis_minion"); z.setPersistenceRequired();
            if (getTarget() != null) z.setTarget(getTarget());
            level().addFreshEntity(z);
        }
    }

    @Override protected SoundEvent getAmbientSound() { return ModSounds.ENCHANTAEGIS_AMBIENT.get(); }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return ModSounds.ENCHANTAEGIS_HURT.get(); }
    @Override protected SoundEvent getDeathSound() { return ModSounds.ENCHANTAEGIS_DEATH.get(); }
}
