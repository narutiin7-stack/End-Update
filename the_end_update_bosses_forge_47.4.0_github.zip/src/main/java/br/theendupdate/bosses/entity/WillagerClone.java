package br.theendupdate.bosses.entity;

import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.PathfinderMob;

/** Isca do Willager: voa em circulos 20-40 blocos acima do alvo e marca bombas. Se atingida, todas as iscas somem. */
public class WillagerClone extends PathfinderMob {
    private UUID ownerId;
    private double angle = Math.random() * 6.28;
    private double radius = 5 + Math.random() * 10;
    private double height = 20 + Math.random() * 20;
    private int bombCooldown = 60;

    public WillagerClone(EntityType<? extends WillagerClone> t, Level l) { super(t, l); setNoGravity(true); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 500.0).add(Attributes.FOLLOW_RANGE, 64.0);
    }

    public void setOwnerId(UUID id) { ownerId = id; }
    public UUID getOwnerId() { return ownerId; }

    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (!level().isClientSide && src.getEntity() != null && ownerId != null) {
            var owner = ((net.minecraft.server.level.ServerLevel) level()).getEntity(ownerId);
            if (owner instanceof WillagerBoss w) { w.despawnClones(); return false; }
            discard(); return false;
        }
        return super.hurt(src, amount);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        var owner = ownerId == null ? null : ((net.minecraft.server.level.ServerLevel) level()).getEntity(ownerId);
        if (!(owner instanceof WillagerBoss w) || !w.isAlive()) { discard(); return; }
        LivingEntity t = w.getTarget();
        if (t == null) return;
        angle += 0.04;
        Vec3 goal = t.position().add(Math.cos(angle) * radius, Math.min(height, 24), Math.sin(angle) * radius);
        Vec3 d = goal.subtract(position());
        setDeltaMovement(d.scale(0.08));
        getLookControl().setLookAt(t, 30, 30);
        if (--bombCooldown <= 0 && distanceTo(t) < 48) {
            bombCooldown = 60;
            for (int i = 0; i < 3; i++) w.bombAt(t.position().add((random.nextDouble() - .5) * 8, 0, (random.nextDouble() - .5) * 8));
        }
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public void addAdditionalSaveData(CompoundTag t) { super.addAdditionalSaveData(t); if (ownerId != null) t.putUUID("Owner", ownerId); }
    @Override public void readAdditionalSaveData(CompoundTag t) { super.readAdditionalSaveData(t); if (t.hasUUID("Owner")) ownerId = t.getUUID("Owner"); }
}
