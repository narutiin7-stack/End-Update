package br.theendupdate.bosses.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Projetil generico dos chefes: dano de impacto, explosao sem quebrar blocos, fogo, gravidade configuravel. */
public class BossProjectile extends ThrowableItemProjectile {
    private float damage = 3.0F;
    private float explosion = 0.0F;
    private boolean fire = false;
    private float grav = 0.03F;
    private int witherSeconds = 0;
    private int life = 200;
    private Item shown = Items.FIRE_CHARGE;

    public BossProjectile(EntityType<? extends BossProjectile> t, Level l) { super(t, l); }

    public BossProjectile(EntityType<? extends BossProjectile> t, Level l, LivingEntity owner) { super(t, owner, l); }

    public BossProjectile life(int ticks) { this.life = ticks; return this; }

    public BossProjectile configure(Item icon, float damage, float explosion, boolean fire, float gravity, int witherSeconds) {
        this.shown = icon; this.damage = damage; this.explosion = explosion; this.fire = fire; this.grav = gravity; this.witherSeconds = witherSeconds;
        this.setItem(icon.getDefaultInstance());
        return this;
    }

    @Override protected Item getDefaultItem() { return shown; }
    @Override protected float getGravity() { return grav; }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && --life <= 0) discard();
    }

    @Override
    protected void onHitEntity(EntityHitResult r) {
        super.onHitEntity(r);
        if (level().isClientSide) return;
        if (r.getEntity() instanceof LivingEntity target && target != getOwner()) {
            DamageSource src = damageSources().mobProjectile(this, getOwner() instanceof LivingEntity o ? o : null);
            target.hurt(src, damage);
            if (fire) target.setSecondsOnFire(5);
            if (witherSeconds > 0) target.addEffect(new MobEffectInstance(MobEffects.WITHER, witherSeconds * 20, 1));
        }
    }

    @Override
    protected void onHit(HitResult r) {
        super.onHit(r);
        if (level().isClientSide) return;
        if (explosion > 0) level().explode(this, getX(), getY(), getZ(), explosion, fire, Level.ExplosionInteraction.NONE);
        discard();
    }

    @Override public void addAdditionalSaveData(CompoundTag t) { super.addAdditionalSaveData(t); t.putFloat("Dmg", damage); t.putFloat("Expl", explosion); t.putBoolean("Fire", fire); t.putFloat("Grav", grav); }
    @Override public void readAdditionalSaveData(CompoundTag t) { super.readAdditionalSaveData(t); damage = t.getFloat("Dmg"); explosion = t.getFloat("Expl"); fire = t.getBoolean("Fire"); grav = t.getFloat("Grav"); }
}
