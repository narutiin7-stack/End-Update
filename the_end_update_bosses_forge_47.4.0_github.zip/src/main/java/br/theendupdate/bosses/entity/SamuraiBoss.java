package br.theendupdate.bosses.entity;

import br.theendupdate.bosses.registry.ModEntities;
import br.theendupdate.bosses.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Samurai Murcho. 350 de vida, imune a fogo/empurrao, toma dano na chuva/agua. Alterna a cada 5 s/3 s entre
 * GOLPE DE ESPADA (dano 6, alcance maior, 1.5 s de preparo) e GIRO (corre atras do alvo a 1.7x, dano 6).
 * Atencao: caveiras de Wither e feixe de chamas existem no pacote do Bedrock, mas o gatilho deles nao veio nos
 * arquivos enviados; aqui eles disparam a cada ~10 s como "ataque carregado" (aproximacao).
 */
public class SamuraiBoss extends BossMob {
    private static final double BASE_SPEED = 0.33;
    private boolean spinning = false;
    private int modeTicks = 0, chargeCooldown = 160;

    public SamuraiBoss(EntityType<? extends SamuraiBoss> t, Level l) {
        super(t, l, BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_6, 10);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 350.0).add(Attributes.MOVEMENT_SPEED, BASE_SPEED)
                .add(Attributes.ATTACK_DAMAGE, 6.0).add(Attributes.FOLLOW_RANGE, 40.0).add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override public boolean fireImmune() { return true; }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0D, false));
        goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 16.0F));
        goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (src.is(DamageTypeTags.IS_FALL)) return false;
        return super.hurt(src, amount);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (isInWaterOrRain() && tickCount % 20 == 0) hurt(damageSources().drown(), 1.0F);
        LivingEntity t = getTarget();
        if (t == null) { setSpin(false); setState(0); return; }
        modeTicks++;
        if (modeTicks > (spinning ? 60 : 100)) { modeTicks = 0; setSpin(random.nextBoolean()); }
        if (chargeCooldown > 0) chargeCooldown--;
        else if (distanceToSqr(t) > 16 && hasLineOfSight(t)) { chargeCooldown = 200; charged(t); }
    }

    private void setSpin(boolean on) {
        spinning = on;
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(on ? BASE_SPEED * 1.7 : BASE_SPEED);
        setState(on ? 1 : 0);
    }

    private void charged(LivingEntity t) {
        playSound(ModSounds.SAMURAI_SHOOT.get(), 2.0F, 1.0F);
        if (random.nextBoolean()) {                                   // caveiras de Wither (dano 6, explosao 1, Wither)
            setState(2);
            for (int i = -1; i <= 1; i++) schedule(10 + (i + 1) * 6, () -> {
                if (getTarget() == null) return;
                BossProjectile p = new BossProjectile(ModEntities.BOSS_PROJECTILE.get(), level(), this)
                        .configure(Items.WITHER_SKELETON_SKULL, 6.0F, 1.0F, false, 0.0F, 5);
                Vec3 d = getTarget().getEyePosition().subtract(getEyePosition()).normalize();
                p.setPos(getX(), getEyeY(), getZ()); p.shoot(d.x, d.y, d.z, 1.2F, 2.0F);
                level().addFreshEntity(p);
            });
        } else {                                                       // feixe de chamas: 12 zonas em linha
            setState(3);
            Vec3 me = position(); double rad = Math.toRadians(yawTo(me, t.position()) + 90);
            for (int i = 1; i <= 12; i++) {
                final Vec3 p = me.add(Math.cos(rad) * i, 0, Math.sin(rad) * i);
                schedule(10 + i * 2, () -> zone(p, 4));
            }
            playSound(ModSounds.SAMURAI_BLAST.get(), 2.0F, 1.0F);
        }
        schedule(50, () -> setState(spinning ? 1 : 0));
    }

    private void zone(Vec3 p, int n) {
        particles(ParticleTypes.FLAME, p.add(0, 0.3, 0), 10, 0.4);
        areaDamage(p, 1.2, 5.0F, 3);
        if (n > 0) schedule(10, () -> zone(p, n - 1));
    }

    @Override protected SoundEvent getAmbientSound() { return ModSounds.SAMURAI_AMBIENT.get(); }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return ModSounds.SAMURAI_HURT.get(); }
    @Override protected SoundEvent getDeathSound() { return ModSounds.SAMURAI_DEATH.get(); }
}
