package br.theendupdate.bosses.entity;

import br.theendupdate.bosses.registry.ModEntities;
import br.theendupdate.bosses.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Phantom;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Flender. Voa pairando a ~9 blocos do alvo. A cada ~4 s sorteia: bola de fogo grande (explosao 2), rajada de bolas
 * pequenas (dano 4, explosao 1.7), 4 phantoms ou mergulho (dano 15, vulneravel x4 ao corpo a corpo). Projeteis
 * causam so 20% de dano. Resiste totalmente a empurrao.
 */
public class FlenderBoss extends BossMob {
    private static final int HOVER = 0, FIREBALL = 1, BURST = 2, PHANTOMS = 3, SWOOP = 4;
    private int mode = HOVER, modeTicks = 0, burstLeft = 0, swoopHitCd = 0;
    private Vec3 swoopDir = Vec3.ZERO;

    public FlenderBoss(EntityType<? extends FlenderBoss> t, Level l) {
        super(t, l, BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.NOTCHED_10, 2000);
        setNoGravity(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 250.0).add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.FLYING_SPEED, 0.3).add(Attributes.ATTACK_DAMAGE, 15.0)
                .add(Attributes.FOLLOW_RANGE, 96.0).add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void registerGoals() {
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, false));
    }

    @Override public boolean isPushable() { return false; }
    @Override public boolean causeFallDamage(float f, float m, DamageSource s) { return false; }

    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (src.is(DamageTypeTags.IS_PROJECTILE)) amount *= 0.2F;
        else if (mode == SWOOP && src.getEntity() != null) amount *= 4.0F;
        return super.hurt(src, amount);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        LivingEntity t = getTarget();
        if (t == null || !t.isAlive()) { setDeltaMovement(getDeltaMovement().scale(0.9)); return; }
        modeTicks++;
        if (swoopHitCd > 0) swoopHitCd--;
        getLookControl().setLookAt(t, 40, 40);
        if (mode == SWOOP) swoop(t); else hover(t);
        switch (mode) {
            case FIREBALL -> { if (modeTicks == 20) fireball(t, true); if (modeTicks > 60) endMode(); }
            case BURST -> { if (modeTicks % 14 == 0 && burstLeft-- > 0) fireball(t, false); if (burstLeft <= 0 && modeTicks > 40) endMode(); }
            case PHANTOMS -> { if (modeTicks == 32) phantoms(t); if (modeTicks > 90) endMode(); }
            case SWOOP -> { if (modeTicks > 80) endMode(); }
            default -> { if (modeTicks > 40) pickMode(); }
        }
    }

    private void endMode() { mode = HOVER; modeTicks = 0; setState(0); }

    private void pickMode() {
        modeTicks = 0;
        switch (random.nextInt(4)) {
            case 0 -> { mode = FIREBALL; }
            case 1 -> { mode = BURST; burstLeft = 16; }
            case 2 -> { mode = PHANTOMS; }
            default -> { mode = SWOOP; }
        }
        setState(mode);
    }

    private void hover(LivingEntity t) {
        Vec3 goal = t.position().add(0, 4, 0).add(position().subtract(t.position()).multiply(1, 0, 1).normalize().scale(9));
        Vec3 d = goal.subtract(position());
        setDeltaMovement(getDeltaMovement().scale(0.85).add(d.normalize().scale(Math.min(0.14, d.length() * 0.02))));
    }

    private void swoop(LivingEntity t) {
        if (modeTicks % 40 == 1) swoopDir = t.getEyePosition().subtract(position()).normalize();
        setDeltaMovement(swoopDir.scale(1.0));
        if (swoopHitCd <= 0 && distanceTo(t) < 2.5) { t.hurt(damageSources().mobAttack(this), 15.0F); swoopHitCd = 20; }
    }

    private void fireball(LivingEntity t, boolean big) {
        BossProjectile p = new BossProjectile(ModEntities.BOSS_PROJECTILE.get(), level(), this)
                .configure(Items.FIRE_CHARGE, big ? 6.0F : 4.0F, big ? 2.0F : 1.7F, false, 0.01F, 0);
        Vec3 d = t.getEyePosition().subtract(getEyePosition()).normalize();
        p.setPos(getX(), getEyeY() - 0.5, getZ()); p.shoot(d.x, d.y, d.z, big ? 1.6F : 1.3F, big ? 0.5F : 4.0F);
        level().addFreshEntity(p);
        playSound(ModSounds.FLENDER_AMBIENT.get(), 3.0F, 1.0F);
    }

    private void phantoms(LivingEntity t) {
        int near = level().getEntitiesOfClass(Phantom.class, getBoundingBox().inflate(48)).size();
        for (int i = 0; i < 4 && near + i < 8; i++) {
            Phantom p = EntityType.PHANTOM.create(level());
            if (p == null) continue;
            double a = i * Math.PI / 2;
            p.moveTo(getX() + Math.cos(a) * 3, getY() + 1, getZ() + Math.sin(a) * 3);
            p.setTarget(t); p.setPersistenceRequired();
            level().addFreshEntity(p);
        }
        particles(ParticleTypes.SOUL, position().add(0, 1, 0), 30, 2);
    }

    @Override protected SoundEvent getAmbientSound() { return ModSounds.FLENDER_AMBIENT.get(); }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return ModSounds.FLENDER_HURT.get(); }
    @Override protected SoundEvent getDeathSound() { return ModSounds.FLENDER_DEATH.get(); }
}
