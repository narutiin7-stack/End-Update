package br.theendupdate.bosses;

import br.theendupdate.bosses.registry.ModEntities;
import br.theendupdate.bosses.registry.ModItems;
import br.theendupdate.bosses.registry.ModSounds;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * Addon "The End Update - Bosses": porta 5 chefes do Better on Bedrock para Forge 1.20.1.
 * Funciona ao lado do mod The End Update (mod separado, mesmo jogo).
 */
@Mod(EndUpdateBosses.MODID)
public class EndUpdateBosses {
    public static final String MODID = "the_end_update_bosses";

    public EndUpdateBosses() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModSounds.SOUNDS.register(bus);
        ModItems.ITEMS.register(bus);
        ModItems.TABS.register(bus);
        ModEntities.ENTITIES.register(bus);
    }
}
