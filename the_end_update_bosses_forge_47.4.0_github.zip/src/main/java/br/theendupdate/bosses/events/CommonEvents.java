package br.theendupdate.bosses.events;

import br.theendupdate.bosses.EndUpdateBosses;
import br.theendupdate.bosses.entity.*;
import br.theendupdate.bosses.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public final class CommonEvents {
    private CommonEvents() {}

    @Mod.EventBusSubscriber(modid = EndUpdateBosses.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class ModBus {
        @SubscribeEvent
        public static void attributes(EntityAttributeCreationEvent e) {
            e.put(ModEntities.WILLAGER.get(), WillagerBoss.createAttributes().build());
            e.put(ModEntities.WILLAGER_CLONE.get(), WillagerClone.createAttributes().build());
            e.put(ModEntities.ENCHANTAEGIS.get(), EnchantaegisBoss.createAttributes().build());
            e.put(ModEntities.FLENDER.get(), FlenderBoss.createAttributes().build());
            e.put(ModEntities.SHIELDED_PYROCLAST.get(), PyroclastBoss.createAttributes().build());
            e.put(ModEntities.WITHERED_SAMURAI.get(), SamuraiBoss.createAttributes().build());
        }
    }

    @Mod.EventBusSubscriber(modid = EndUpdateBosses.MODID)
    public static final class ForgeBus {
        private static final String WILLAGER_CHEST = EndUpdateBosses.MODID + ":chests/willager_arena";

        /** Willager: acorda quando o jogador abre o bau central da arena (o bau ainda tem a tabela de loot da arena). */
        @SubscribeEvent
        public static void openChest(PlayerInteractEvent.RightClickBlock e) {
            if (e.getLevel().isClientSide || !(e.getLevel() instanceof ServerLevel level)) return;
            BlockEntity be = level.getBlockEntity(e.getPos());
            if (!(be instanceof ChestBlockEntity chest)) return;
            if (!WILLAGER_CHEST.equals(chest.saveWithoutMetadata().getString("LootTable"))) return;
            BlockPos p = e.getPos();
            if (!level.getEntitiesOfClass(WillagerBoss.class, new net.minecraft.world.phys.AABB(p).inflate(64)).isEmpty()) return;
            WillagerBoss boss = ModEntities.WILLAGER.get().create(level);
            if (boss == null) return;
            boss.moveTo(p.getX() + 0.5, p.getY() + 1.0, p.getZ() + 3.5, 0, 0);
            boss.finalizeSpawn(level, level.getCurrentDifficultyAt(p), MobSpawnType.EVENT, null, null);
            boss.setTarget(e.getEntity());
            level.addFreshEntity(boss);
        }
    }
}
