package br.theendupdate.bosses.client;

import net.minecraft.client.model.geom.builders.*;

/** GERADO automaticamente a partir dos .geo.json do Better on Bedrock. */
public final class BossModelDefs {
    private BossModelDefs() {}

    public static LayerDefinition willager() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition b_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(33, 56).mirror(false).addBox(-4F, -1.74F, -3F, 8F, 12F, 6F, new CubeDeformation(-1.16F, -1.74F, -0.87F)).texOffs(37, 29).mirror(false).addBox(-4F, -2.9F, -3F, 8F, 20F, 6F, new CubeDeformation(-0.805F, -2.545F, -0.515F)), PartPose.offset(0F, 7F, 0F));
        PartDefinition b_leg1 = b_body.addOrReplaceChild("leg1", CubeListBuilder.create().texOffs(66, 26).mirror(false).addBox(-2F, -1.74F, -2F, 4F, 12F, 4F, new CubeDeformation(-0.58F, -1.74F, -0.58F)), PartPose.offset(-1.42F, 8.52F, 0F));
        PartDefinition b_leg0 = b_body.addOrReplaceChild("leg0", CubeListBuilder.create().texOffs(17, 71).mirror(false).addBox(-2F, -1.74F, -2F, 4F, 12F, 4F, new CubeDeformation(-0.58F, -1.74F, -0.58F)), PartPose.offset(1.42F, 8.52F, 0F));
        PartDefinition b_head = b_body.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 48).mirror(false).addBox(-4F, -7.695F, -4F, 8F, 9F, 8F, new CubeDeformation(-1.16F, -1.305F, -1.16F)).texOffs(60, 50).mirror(false).addBox(-4F, -3.42F, -2.29F, 8F, 4F, 6F, new CubeDeformation(-0.7979F, -0.2179F, -0.5079F)).texOffs(41, 7).mirror(false).addBox(-4F, -14.94F, -4F, 8F, 10F, 8F, new CubeDeformation(-1.16F, -1.45F, -1.16F)).texOffs(0, 15).mirror(false).addBox(-6F, -7.245F, -6F, 12F, 1F, 12F, new CubeDeformation(-1.74F, -0.145F, -1.74F)).texOffs(0, 0).mirror(false).addBox(-6F, -8.81F, -6F, 12F, 2F, 12F, new CubeDeformation(-1.74F, -0.29F, -1.74F)), PartPose.offset(0F, 0F, 0F));
        PartDefinition b_nose = b_head.addOrReplaceChild("nose", CubeListBuilder.create().texOffs(0, 0).mirror(false).addBox(-1F, -1.29F, -4.55F, 2F, 4F, 2F, new CubeDeformation(-0.29F, -0.58F, -0.29F)), PartPose.offset(0F, -1.42F, 0F));
        PartDefinition b_rightarm = b_body.addOrReplaceChild("rightarm", CubeListBuilder.create().texOffs(0, 66).mirror(false).addBox(-1.29F, -3.16F, -2F, 4F, 12F, 4F, new CubeDeformation(-0.58F, -1.74F, -0.58F)).texOffs(74, 11).mirror(false).addBox(-1.29F, -2.29F, -2F, 4F, 6F, 4F, new CubeDeformation(-0.225F, -0.515F, -0.225F)).texOffs(80, 98).mirror(false).addBox(-1.29F, -2.58F, -2F, 4F, 8F, 4F, new CubeDeformation(-0.58F, -1.16F, -0.58F)), PartPose.offset(-5.68F, 1.42F, 0F));
        PartDefinition b_Cane2 = b_rightarm.addOrReplaceChild("Cane2", CubeListBuilder.create().texOffs(0, 29).mirror(false).addBox(-0.29F, 4.68F, -8F, 2F, 2F, 16F, new CubeDeformation(-0.29F, -0.29F, -2.32F)).texOffs(0, 15).mirror(false).addBox(-0.29F, 5.955F, -5.97F, 2F, 3F, 2F, new CubeDeformation(-0.29F, -0.435F, -0.29F)), PartPose.offset(0F, -0F, 0F));
        PartDefinition b_leftarm = b_body.addOrReplaceChild("leftarm", CubeListBuilder.create().texOffs(62, 61).mirror(false).addBox(-2.71F, -3.16F, -2F, 4F, 12F, 4F, new CubeDeformation(-0.58F, -1.74F, -0.58F)).texOffs(66, 0).mirror(false).addBox(-2.71F, -2.29F, -2F, 4F, 6F, 4F, new CubeDeformation(-0.225F, -0.515F, -0.225F)), PartPose.offset(5.68F, 1.42F, 0F));
        PartDefinition b_arms = b_leftarm.addOrReplaceChild("arms", CubeListBuilder.create().texOffs(80, 98).mirror(false).addBox(-6.26F, -2.58F, -2F, 4F, 8F, 4F, new CubeDeformation(-0.58F, -1.16F, -0.58F)), PartPose.offset(3.55F, -0F, 0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    public static LayerDefinition enchantaegis() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition b_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 58).mirror(false).addBox(-4F, -12F, -3F, 8F, 12F, 6F, new CubeDeformation(0F, 0F, 0F)).texOffs(28, 66).mirror(false).addBox(-4F, -13F, -3F, 8F, 12F, 6F, new CubeDeformation(0.25F, 0F, 0.25F)), PartPose.offset(0F, 12F, 0F));
        PartDefinition b_coolmagething = b_body.addOrReplaceChild("coolmagething", CubeListBuilder.create(), PartPose.offset(0F, -12F, 3F));
        b_coolmagething.addOrReplaceChild("coolmagething_r0", CubeListBuilder.create().texOffs(66, 42).mirror(false).addBox(0F, -0F, -3F, 0F, 22F, 6F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(-4F, 0F, -3F, 0F, 0F, 0.0524F));
        b_coolmagething.addOrReplaceChild("coolmagething_r1", CubeListBuilder.create().texOffs(32, 84).mirror(false).addBox(0F, -0F, -2F, 0F, 22F, 2F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(-4F, 0F, -6F, 0F, 0.733F, 0.0524F));
        b_coolmagething.addOrReplaceChild("coolmagething_r2", CubeListBuilder.create().texOffs(0, -2).mirror(false).addBox(0F, -0F, -2F, 0F, 22F, 2F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(4F, 0F, -6F, 0F, -0.733F, -0.0524F));
        b_coolmagething.addOrReplaceChild("coolmagething_r3", CubeListBuilder.create().texOffs(68, 70).mirror(false).addBox(0F, -0F, -3F, 0F, 22F, 6F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(4F, 0F, -3F, 0F, 0F, -0.0524F));
        b_coolmagething.addOrReplaceChild("coolmagething_r4", CubeListBuilder.create().texOffs(0, 0).mirror(false).addBox(-4F, -0F, 0F, 8F, 22F, 0F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(0F, 0F, 0F, -0.0524F, 0F, 0F));
        PartDefinition b_rightarm = b_body.addOrReplaceChild("rightarm", CubeListBuilder.create().texOffs(78, 43).mirror(false).addBox(-1F, -2F, -2F, 4F, 12F, 4F, new CubeDeformation(0F, 0F, 0F)).texOffs(40, 84).mirror(false).addBox(-1F, -2F, -2F, 4F, 7F, 4F, new CubeDeformation(0.3F, 0.3F, 0.3F)), PartPose.offset(5F, -10F, 0F));
        PartDefinition b_leftarm = b_body.addOrReplaceChild("leftarm", CubeListBuilder.create().texOffs(16, 84).mirror(false).addBox(-3F, -2F, -2F, 4F, 12F, 4F, new CubeDeformation(0F, 0F, 0F)).texOffs(78, 59).mirror(false).addBox(-3F, -2F, -2F, 4F, 7F, 4F, new CubeDeformation(0.3F, 0.3F, 0.3F)), PartPose.offset(-5F, -10F, 0F));
        PartDefinition b_head = b_body.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 40).mirror(false).addBox(-4F, -10F, -4F, 8F, 10F, 8F, new CubeDeformation(0F, 0F, 0F)).texOffs(0, 16).mirror(false).addBox(-4F, -10F, -4F, 8F, 16F, 8F, new CubeDeformation(0.25F, 0F, 0.25F)).texOffs(16, 76).mirror(false).addBox(-1F, -3F, -6F, 2F, 4F, 2F, new CubeDeformation(0F, 0F, 0F)), PartPose.offset(0F, -12F, 0F));
        PartDefinition b_hat = b_head.addOrReplaceChild("hat", CubeListBuilder.create().texOffs(0, -16).mirror(false).addBox(-6.75F, 2.0833F, -8F, 12F, 0F, 16F, new CubeDeformation(0F, 0F, 0F)).texOffs(32, 16).mirror(false).addBox(-5.75F, -0.9167F, -5F, 10F, 3F, 10F, new CubeDeformation(0.25F, 0F, 0.25F)).texOffs(32, 29).mirror(false).addBox(-5.75F, -0.9917F, -5F, 10F, 3F, 10F, new CubeDeformation(0F, 0F, 0F)).texOffs(72, 18).mirror(false).addBox(-3.75F, -3.9167F, -3F, 6F, 3F, 6F, new CubeDeformation(0F, 0F, 0F)).texOffs(72, 11).mirror(false).addBox(-3.75F, -8.9167F, 0F, 15F, 7F, 0F, new CubeDeformation(0F, 0F, 0F)).texOffs(56, 0).mirror(false).addBox(-4.75F, -1.9167F, -4F, 8F, 3F, 8F, new CubeDeformation(0F, 0F, 0F)), PartPose.offset(0.75F, -11.0833F, 0F));
        b_hat.addOrReplaceChild("hat_r0", CubeListBuilder.create().texOffs(0, -12).mirror(false).addBox(0F, 0F, -6F, 5F, 0F, 12F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(5.25F, 2.0833F, 0F, 0F, 0F, 0.3927F));
        b_hat.addOrReplaceChild("hat_r1", CubeListBuilder.create().texOffs(0, -12).mirror(false).addBox(-5F, 0F, -6F, 5F, 0F, 12F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(-6.75F, 2.0833F, 0F, 0F, 0F, 0.3927F));
        PartDefinition b_leg0 = root.addOrReplaceChild("leg0", CubeListBuilder.create().texOffs(0, 76).mirror(false).addBox(-2F, -0F, -2F, 4F, 12F, 4F, new CubeDeformation(0F, 0F, 0F)), PartPose.offset(2F, 12F, 0F));
        PartDefinition b_leg1 = root.addOrReplaceChild("leg1", CubeListBuilder.create().texOffs(78, 27).mirror(false).addBox(-2F, -0F, -2F, 4F, 12F, 4F, new CubeDeformation(0F, 0F, 0F)), PartPose.offset(-2F, 12F, 0F));
        return LayerDefinition.create(mesh, 112, 112);
    }

    public static LayerDefinition flender() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition b_Body = root.addOrReplaceChild("Body", CubeListBuilder.create().texOffs(0, 51).mirror(false).addBox(-6F, -8F, -8F, 12F, 8F, 21F, new CubeDeformation(0F, 0F, 0F)), PartPose.offset(0F, 24F, 0F));
        b_Body.addOrReplaceChild("Body_r0", CubeListBuilder.create().texOffs(0, 101).mirror(false).addBox(14.0349F, -46.7892F, -10F, 1F, 10F, 23F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(0F, 34F, 0F, 0F, 0F, -0.48F));
        b_Body.addOrReplaceChild("Body_r1", CubeListBuilder.create().texOffs(0, 101).mirror().addBox(-15.0349F, -46.7892F, -10F, 1F, 10F, 23F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(0F, 34F, 0F, 0F, 0F, 0.48F));
        PartDefinition b_Head = b_Body.addOrReplaceChild("Head", CubeListBuilder.create(), PartPose.offset(0F, 0F, 0F));
        b_Head.addOrReplaceChild("Head_r0", CubeListBuilder.create().texOffs(0, 80).mirror(false).addBox(-4.9932F, -40.8188F, -9.01F, 14F, 6F, 14F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(0F, 34F, 0F, -0.1736F, -0.7778F, 0.1225F));
        b_Head.addOrReplaceChild("Head_r1", CubeListBuilder.create().texOffs(0, 30).mirror(false).addBox(-5.636F, -36F, -13.364F, 19F, 2F, 19F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(0F, 34F, 0F, 0F, -0.7854F, 0F));
        PartDefinition b_Tail = b_Body.addOrReplaceChild("Tail", CubeListBuilder.create(), PartPose.offsetAndRotation(0F, -4F, 12F, 0.2618F, 0F, 0F));
        b_Tail.addOrReplaceChild("Tail_r0", CubeListBuilder.create().texOffs(49, 30).mirror(false).addBox(-1F, -47.5892F, 5.0267F, 1F, 4F, 27F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(0F, 38F, -12F, 0.3491F, 0F, 0F));
        b_Tail.addOrReplaceChild("Tail_r1", CubeListBuilder.create().texOffs(78, 38).mirror(false).addBox(-3F, -36.4428F, 21.6157F, 6F, 6F, 10F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(0F, 38F, -12F, -0.2618F, 0F, 0F));
        PartDefinition b_Wings3 = b_Body.addOrReplaceChild("Wings3", CubeListBuilder.create(), PartPose.offset(6F, -7F, 4F));
        b_Wings3.addOrReplaceChild("Wings3_r0", CubeListBuilder.create().texOffs(82, 5).mirror().addBox(12.936F, -39.3361F, -1.9429F, 18F, 2F, 3F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(-6F, 41F, -4F, 0.0306F, -0.1719F, -0.1772F));
        b_Wings3.addOrReplaceChild("Wings3_r1", CubeListBuilder.create().texOffs(53, 75).mirror().addBox(9.936F, -38.3361F, 1.0571F, 21F, 1F, 13F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(-6F, 41F, -4F, 0.0306F, -0.1719F, -0.1772F));
        b_Wings3.addOrReplaceChild("Wings3_r2", CubeListBuilder.create().texOffs(122, 50).mirror().addBox(20.1562F, -42.892F, -15.5423F, 2F, 2F, 21F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(-6F, 41F, -4F, 0.0873F, 0.2182F, 0F));
        PartDefinition b_win3 = b_Wings3.addOrReplaceChild("win3", CubeListBuilder.create(), PartPose.offset(16.587F, -2.3763F, -5F));
        b_win3.addOrReplaceChild("win3_r0", CubeListBuilder.create().texOffs(78, 34).mirror().addBox(5.0054F, -46.8601F, -17.7386F, 34F, 2F, 2F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(-22.587F, 43.3763F, 1F, 0.1634F, 0.5457F, 0.3076F));
        b_win3.addOrReplaceChild("win3_r1", CubeListBuilder.create().texOffs(0, 15).mirror().addBox(5.0054F, -45.8601F, -15.7386F, 34F, 1F, 14F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(-22.587F, 43.3763F, 1F, 0.1634F, 0.5457F, 0.3076F));
        PartDefinition b_Wings2 = b_Body.addOrReplaceChild("Wings2", CubeListBuilder.create(), PartPose.offset(-6F, -7F, 4F));
        b_Wings2.addOrReplaceChild("Wings2_r0", CubeListBuilder.create().texOffs(82, 5).mirror(false).addBox(-30.936F, -39.3361F, -1.9429F, 18F, 2F, 3F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(6F, 41F, -4F, 0.0306F, 0.1719F, 0.1772F));
        b_Wings2.addOrReplaceChild("Wings2_r1", CubeListBuilder.create().texOffs(53, 75).mirror(false).addBox(-30.936F, -38.3361F, 1.0571F, 21F, 1F, 13F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(6F, 41F, -4F, 0.0306F, 0.1719F, 0.1772F));
        b_Wings2.addOrReplaceChild("Wings2_r2", CubeListBuilder.create().texOffs(122, 50).mirror(false).addBox(-22.1562F, -42.892F, -15.5423F, 2F, 2F, 21F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(6F, 41F, -4F, 0.0873F, -0.2182F, 0F));
        PartDefinition b_win2 = b_Wings2.addOrReplaceChild("win2", CubeListBuilder.create(), PartPose.offset(-16.587F, -2.3763F, -5F));
        b_win2.addOrReplaceChild("win2_r0", CubeListBuilder.create().texOffs(78, 34).mirror(false).addBox(-39.0055F, -46.8601F, -17.7386F, 34F, 2F, 2F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(22.587F, 43.3763F, 1F, 0.1634F, -0.5457F, -0.3076F));
        b_win2.addOrReplaceChild("win2_r1", CubeListBuilder.create().texOffs(0, 15).mirror(false).addBox(-39.0055F, -45.8601F, -15.7386F, 34F, 1F, 14F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(22.587F, 43.3763F, 1F, 0.1634F, -0.5457F, -0.3076F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static LayerDefinition lich() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition b_body = root.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offsetAndRotation(0F, -10F, 0F, -1.5708F, 0F, 0F));
        PartDefinition b_chest = b_body.addOrReplaceChild("chest", CubeListBuilder.create(), PartPose.offsetAndRotation(0F, 1.9F, 12.116F, -3.1416F, 0F, -1.5708F));
        PartDefinition b_spine = b_chest.addOrReplaceChild("spine", CubeListBuilder.create(), PartPose.offsetAndRotation(0F, -0F, 0F, 0F, 0.0003F, -0.0002F));
        b_spine.addOrReplaceChild("spine_r0", CubeListBuilder.create().texOffs(111, 26).mirror(false).addBox(-1.005F, -43.72F, 1.015F, 2F, 24F, 2F, new CubeDeformation(0.001F, 0.009F, 0.004F)), PartPose.offsetAndRotation(1.915F, -0F, 46.115F, -1.5705F, 0F, -1.5706F));
        PartDefinition b_upper_ribs = b_spine.addOrReplaceChild("upper_ribs", CubeListBuilder.create(), PartPose.offset(0F, -0F, 9.087F));
        PartDefinition b_lower_ribs = b_spine.addOrReplaceChild("lower_ribs", CubeListBuilder.create(), PartPose.offset(0F, -0F, 9.087F));
        b_lower_ribs.addOrReplaceChild("lower_ribs_r0", CubeListBuilder.create().texOffs(7, 106).mirror(false).addBox(-6.0045F, -35.722F, -2.9865F, 12F, 2F, 6F, new CubeDeformation(0.0045F, 0.001F, 0.0055F)), PartPose.offsetAndRotation(1.915F, -0F, 37.028F, -1.5705F, 0F, -1.5706F));
        b_lower_ribs.addOrReplaceChild("lower_ribs_r1", CubeListBuilder.create().texOffs(7, 106).mirror(false).addBox(-6.0045F, -39.725F, -2.9865F, 12F, 2F, 6F, new CubeDeformation(0.0045F, 0.001F, 0.0055F)), PartPose.offsetAndRotation(1.915F, -0F, 37.028F, -1.5705F, 0F, -1.5706F));
        b_lower_ribs.addOrReplaceChild("lower_ribs_r2", CubeListBuilder.create().texOffs(7, 106).mirror(false).addBox(-6.0045F, -27.722F, -2.9865F, 12F, 2F, 6F, new CubeDeformation(0.0045F, 0.001F, 0.0055F)), PartPose.offsetAndRotation(1.915F, -0F, 37.028F, -1.5705F, 0F, -1.5706F));
        b_lower_ribs.addOrReplaceChild("lower_ribs_r3", CubeListBuilder.create().texOffs(7, 106).mirror(false).addBox(-6.0045F, -31.725F, -2.9865F, 12F, 2F, 6F, new CubeDeformation(0.0045F, 0.001F, 0.0055F)), PartPose.offsetAndRotation(1.915F, -0F, 37.028F, -1.5705F, 0F, -1.5706F));
        PartDefinition b_lower_spine = b_spine.addOrReplaceChild("lower_spine", CubeListBuilder.create(), PartPose.offset(0F, -0F, 24.018F));
        PartDefinition b_cape = b_chest.addOrReplaceChild("cape", CubeListBuilder.create(), PartPose.offsetAndRotation(-2.917F, -0F, 4.102F, 0F, 0.0016F, -0F));
        b_cape.addOrReplaceChild("cape_r0", CubeListBuilder.create().texOffs(62, 1).mirror(false).addBox(-7.0045F, -54.974F, -4.0235F, 14F, 42F, 9F, new CubeDeformation(0.0055F, 0.016F, 0.0035F)), PartPose.offsetAndRotation(4.882F, -0F, 42.006F, -1.5692F, 0F, -1.5708F));
        PartDefinition b_hood = b_chest.addOrReplaceChild("hood", CubeListBuilder.create(), PartPose.offsetAndRotation(-2.917F, -0F, 5.102F, 0F, 3.141F, 0.0001F));
        PartDefinition b_head = b_hood.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offsetAndRotation(-2.919F, -0F, 4.101F, 0F, 0F, 0.0007F));
        b_head.addOrReplaceChild("head_r0", CubeListBuilder.create().texOffs(14, 79).mirror(false).addBox(-6.0045F, -57.988F, -6.034F, 12F, 13F, 11F, new CubeDeformation(0.0045F, 0.005F, 0.001F)), PartPose.offsetAndRotation(-1.871F, 0.001F, -46.117F, 1.5702F, 0F, -1.5714F));
        PartDefinition b_crown = b_head.addOrReplaceChild("crown", CubeListBuilder.create(), PartPose.offsetAndRotation(-4.353F, 0.25F, 21.925F, -1.5727F, -1.5702F, 0.0019F));
        b_crown.addOrReplaceChild("crown_r0", CubeListBuilder.create().texOffs(0, 0).mirror(false).addBox(-4.008F, -62.9945F, -7.0365F, 2F, 4F, 0F, new CubeDeformation(0.002F, 0.0015F, 0.0005F)), PartPose.offsetAndRotation(68.0435F, 2.4397F, 0.252F, 1.5708F, 1.5708F, 0F));
        b_crown.addOrReplaceChild("crown_r1", CubeListBuilder.create().texOffs(0, 0).mirror(false).addBox(2F, -62.9945F, -7.0355F, 2F, 4F, 0F, new CubeDeformation(0.002F, 0.0015F, 0.0005F)), PartPose.offsetAndRotation(68.0435F, 2.4397F, 0.252F, 1.5708F, 1.5708F, 0F));
        PartDefinition b_shard = b_head.addOrReplaceChild("shard", CubeListBuilder.create(), PartPose.offsetAndRotation(-3.664F, 0.008F, -13.502F, -2.3562F, -0.7848F, -0.0006F));
        b_shard.addOrReplaceChild("shard_r0", CubeListBuilder.create().texOffs(122, -3).mirror(false).addBox(-3.5695F, -1.183F, -2.417F, 6F, 6F, 6F, new CubeDeformation(-0.8F, -0.8F, -0.8F)), PartPose.offsetAndRotation(-2.3548F, -0.1034F, -0.6031F, -2.7199F, 0.2221F, 2.0555F));
        PartDefinition b_left_eye = b_head.addOrReplaceChild("left_eye", CubeListBuilder.create(), PartPose.offsetAndRotation(-8.096F, -2.498F, 7.896F, -1.6037F, -1.5707F, 0.0324F));
        b_left_eye.addOrReplaceChild("left_eye_r0", CubeListBuilder.create().texOffs(58, 1).mirror(false).addBox(0.997F, -55.99F, -6.07F, 3F, 2F, 0F, new CubeDeformation(0.001F, 0.001F, 0F)), PartPose.offsetAndRotation(54.014F, 6.222F, -2.498F, -0.0032F, 1.5702F, -1.5737F));
        PartDefinition b_right_eye = b_head.addOrReplaceChild("right_eye", CubeListBuilder.create(), PartPose.offsetAndRotation(-8.093F, 2.506F, 7.896F, -1.6057F, -1.5707F, 0.0334F));
        b_right_eye.addOrReplaceChild("right_eye_r0", CubeListBuilder.create().texOffs(51, 1).mirror(false).addBox(-4.007F, -55.99F, -6.07F, 3F, 2F, 0F, new CubeDeformation(0.001F, 0.001F, 0F)), PartPose.offsetAndRotation(54.014F, 6.219F, 2.506F, -0.0031F, 1.5702F, -1.5733F));
        PartDefinition b_mouth = b_head.addOrReplaceChild("mouth", CubeListBuilder.create(), PartPose.offsetAndRotation(-8.09F, 0.004F, 2.884F, -1.6037F, -1.5707F, 0.0328F));
        b_mouth.addOrReplaceChild("mouth_r0", CubeListBuilder.create().texOffs(54, 9).mirror(false).addBox(-2.0045F, -48.985F, -6.07F, 4F, 2F, 0F, new CubeDeformation(0.0015F, 0.001F, 0F)), PartPose.offsetAndRotation(49.001F, 6.217F, 0.004F, -0.0032F, 1.5702F, -1.5737F));
        PartDefinition b_leftSleeve = b_chest.addOrReplaceChild("leftSleeve", CubeListBuilder.create(), PartPose.offsetAndRotation(2.985F, -10.008F, 3.67F, 0F, -3.1387F, 0.0003F));
        b_leftSleeve.addOrReplaceChild("leftSleeve_r0", CubeListBuilder.create().texOffs(90, 52).mirror(false).addBox(7.2455F, -51.978F, -3.034F, 6F, 24F, 7F, new CubeDeformation(0.0025F, 0.009F, 0.006F)), PartPose.offsetAndRotation(0.96F, 10.008F, -42.449F, 1.5736F, 0F, -1.5705F));
        b_leftSleeve.addOrReplaceChild("leftSleeve_r1", CubeListBuilder.create().texOffs(90, 52).mirror(false).addBox(7.243F, -41.987F, -3.04F, 6.005F, 0F, 7.012F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(0.96F, 10.008F, -42.449F, 1.5736F, 0F, -1.5705F));
        PartDefinition b_leftShoulder = b_leftSleeve.addOrReplaceChild("leftShoulder", CubeListBuilder.create(), PartPose.offsetAndRotation(0F, -0F, 0F, 0F, -3.1416F, 0F));
        b_leftShoulder.addOrReplaceChild("leftShoulder_r0", CubeListBuilder.create().texOffs(111, 28).mirror(false).addBox(9.246F, -39.557F, -2.037F, 2F, 10F, 2F, new CubeDeformation(0.001F, 0.422F, 0.001F)), PartPose.offsetAndRotation(-0.961F, 10.008F, 42.448F, -1.568F, 0F, -1.5711F));
        PartDefinition b_leftElbow = b_leftShoulder.addOrReplaceChild("leftElbow", CubeListBuilder.create(), PartPose.offset(0F, -0F, 10.989F));
        b_leftElbow.addOrReplaceChild("leftElbow_r0", CubeListBuilder.create().texOffs(111, 40).mirror(false).addBox(9.246F, -28.725F, -2.037F, 2F, 10F, 2F, new CubeDeformation(0.001F, 0.422F, 0.001F)), PartPose.offsetAndRotation(-0.961F, 10.008F, 31.459F, -1.568F, 0F, -1.5711F));
        PartDefinition b_leftWrist = b_leftElbow.addOrReplaceChild("leftWrist", CubeListBuilder.create(), PartPose.offset(0F, -0F, 10.844F));
        PartDefinition b_rightSleeve = b_chest.addOrReplaceChild("rightSleeve", CubeListBuilder.create(), PartPose.offsetAndRotation(2.985F, 10.008F, 3.67F, 0F, 0.0028F, -0.0003F));
        b_rightSleeve.addOrReplaceChild("rightSleeve_r0", CubeListBuilder.create().texOffs(62, 52).mirror(false).addBox(-13.2605F, -51.979F, -3.033F, 6F, 24F, 7F, new CubeDeformation(0.0025F, 0.009F, 0.006F)), PartPose.offsetAndRotation(-0.961F, -10.008F, 42.448F, -1.568F, 0F, -1.5705F));
        b_rightSleeve.addOrReplaceChild("rightSleeve_r1", CubeListBuilder.create().texOffs(62, 52).mirror(false).addBox(-13.263F, -41.988F, -3.039F, 6.005F, 0F, 7.012F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(-0.961F, -10.008F, 42.448F, -1.568F, 0F, -1.5705F));
        PartDefinition b_rightShoulder = b_rightSleeve.addOrReplaceChild("rightShoulder", CubeListBuilder.create(), PartPose.offset(0F, -0F, 0F));
        b_rightShoulder.addOrReplaceChild("rightShoulder_r0", CubeListBuilder.create().texOffs(113, 30).mirror(false).addBox(-11.248F, -39.558F, -2.037F, 2F, 10F, 2F, new CubeDeformation(0.001F, 0.422F, 0.001F)), PartPose.offsetAndRotation(-0.961F, -10.008F, 42.448F, -1.568F, 0F, -1.5705F));
        PartDefinition b_rightElbow = b_rightShoulder.addOrReplaceChild("rightElbow", CubeListBuilder.create(), PartPose.offset(0F, -0F, 10.989F));
        b_rightElbow.addOrReplaceChild("rightElbow_r0", CubeListBuilder.create().texOffs(111, 40).mirror(false).addBox(-11.265F, -28.726F, -2.037F, 2F, 10F, 2F, new CubeDeformation(0.001F, 0.422F, 0.001F)), PartPose.offsetAndRotation(-0.961F, -10.008F, 31.459F, -1.568F, 0F, -1.5705F));
        PartDefinition b_rightWrist = b_rightElbow.addOrReplaceChild("rightWrist", CubeListBuilder.create(), PartPose.offset(0F, -0F, 10.838F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static LayerDefinition pyroclast() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition b_root = root.addOrReplaceChild("root", CubeListBuilder.create(), PartPose.offset(0F, 30F, 0F));
        PartDefinition b_head = b_root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(16, 18).mirror(false).addBox(-4F, -9F, -4F, 8F, 8F, 8F, new CubeDeformation(0F, 0F, 0F)).texOffs(0, 105).mirror(false).addBox(-4.5F, -15F, -4.25F, 9F, 14F, 9F, new CubeDeformation(0F, 0F, 0F)), PartPose.offset(0F, -41F, 0F));
        PartDefinition b_bone = b_root.addOrReplaceChild("bone", CubeListBuilder.create(), PartPose.offset(0F, 0F, 0F));
        PartDefinition b_bone5 = b_bone.addOrReplaceChild("bone5", CubeListBuilder.create(), PartPose.offset(0F, -1F, 0F));
        PartDefinition b_bone7 = b_bone5.addOrReplaceChild("bone7", CubeListBuilder.create(), PartPose.offset(6F, -38F, 0F));
        b_bone7.addOrReplaceChild("bone7_r0", CubeListBuilder.create().texOffs(36, 34).mirror(false).addBox(-4F, -1F, 2F, 8F, 20F, 2F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, -1.5708F, 0F));
        PartDefinition b_bone8 = b_bone5.addOrReplaceChild("bone8", CubeListBuilder.create().texOffs(54, 54).mirror(false).addBox(-4F, -3F, -4F, 8F, 20F, 2F, new CubeDeformation(0F, 0F, 0F)), PartPose.offset(0F, -36F, -6F));
        PartDefinition b_bone9 = b_bone5.addOrReplaceChild("bone9", CubeListBuilder.create(), PartPose.offset(-6F, -37F, 0F));
        b_bone9.addOrReplaceChild("bone9_r0", CubeListBuilder.create().texOffs(16, 34).mirror(false).addBox(-4F, -2F, -4F, 8F, 20F, 2F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, -1.5708F, 0F));
        PartDefinition b_bone10 = b_bone5.addOrReplaceChild("bone10", CubeListBuilder.create().texOffs(40, 0).mirror(false).addBox(2F, -2F, 2F, 8F, 20F, 2F, new CubeDeformation(0F, 0F, 0F)), PartPose.offset(-6F, -37F, 6F));
        PartDefinition b_bone2 = b_bone.addOrReplaceChild("bone2", CubeListBuilder.create().texOffs(108, 62).mirror(false).addBox(-4F, -39F, -7F, 8F, 9F, 2F, new CubeDeformation(0F, 0F, 0F)).texOffs(94, 8).mirror(false).addBox(-4F, -39F, 5F, 8F, 9F, 2F, new CubeDeformation(0F, 0F, 0F)), PartPose.offset(0F, 20F, 0F));
        b_bone2.addOrReplaceChild("bone2_r0", CubeListBuilder.create().texOffs(90, 42).mirror(false).addBox(-4F, -1F, -1F, 8F, 9F, 2F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(6F, -38F, 0F, 0F, -1.5708F, 0F));
        b_bone2.addOrReplaceChild("bone2_r1", CubeListBuilder.create().texOffs(70, 42).mirror(false).addBox(-4F, -2F, -1F, 8F, 9F, 2F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(-6F, -37F, 0F, 0F, -1.5708F, 0F));
        PartDefinition b_bone3 = b_bone.addOrReplaceChild("bone3", CubeListBuilder.create().texOffs(108, 62).mirror(false).addBox(-4F, -39F, -7F, 8F, 9F, 2F, new CubeDeformation(0F, 0F, 0F)).texOffs(94, 8).mirror(false).addBox(-4F, -39F, 5F, 8F, 9F, 2F, new CubeDeformation(0F, 0F, 0F)), PartPose.offset(0F, -4F, 0F));
        b_bone3.addOrReplaceChild("bone3_r0", CubeListBuilder.create().texOffs(90, 42).mirror(false).addBox(-4F, -1F, -1F, 8F, 9F, 2F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(6F, -38F, 0F, 0F, -1.5708F, 0F));
        b_bone3.addOrReplaceChild("bone3_r1", CubeListBuilder.create().texOffs(70, 42).mirror(false).addBox(-4F, -2F, -1F, 8F, 9F, 2F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(-6F, -37F, 0F, 0F, -1.5708F, 0F));
        PartDefinition b_bone4 = b_root.addOrReplaceChild("bone4", CubeListBuilder.create(), PartPose.offset(0F, 0F, 0F));
        b_bone4.addOrReplaceChild("bone4_r0", CubeListBuilder.create().texOffs(0, 18).mirror(false).addBox(-2F, -39F, -2F, 4F, 32F, 4F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, -1.5708F, 0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    public static LayerDefinition samurai() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition b_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(38, 0).mirror(false).addBox(-6F, -4F, -3F, 12F, 10F, 7F, new CubeDeformation(0.5F, 0.5F, 0.5F)).texOffs(0, 19).mirror(false).addBox(-6F, -3F, -3F, 12F, 12F, 7F, new CubeDeformation(1F, 1F, 1F)).texOffs(32, 32).mirror(false).addBox(-6F, 4F, -3F, 12F, 14F, 6F, new CubeDeformation(0.25F, 0.25F, 0.25F)).texOffs(0, 0).mirror(false).addBox(-6F, -15F, -3F, 12F, 12F, 7F, new CubeDeformation(0F, 0F, 0F)), PartPose.offset(0F, 6F, 0F));
        b_body.addOrReplaceChild("body_r0", CubeListBuilder.create().texOffs(66, 55).mirror(false).addBox(1F, -26F, -4F, 10F, 3F, 9F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0.1309F));
        b_body.addOrReplaceChild("body_r1", CubeListBuilder.create().texOffs(59, 43).mirror(false).addBox(-5F, -74F, -4F, 10F, 3F, 9F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(0F, 58F, 0F, 0F, 0F, -0.1309F));
        b_body.addOrReplaceChild("body_r2", CubeListBuilder.create().texOffs(0, 38).mirror(false).addBox(-18F, -28F, -30F, 3F, 36F, 4F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(10F, -23F, 20F, -1.3963F, 0F, 0F));
        PartDefinition b_sword_sheathed = b_body.addOrReplaceChild("sword_sheathed", CubeListBuilder.create().texOffs(14, 71).mirror(false).addBox(-0.5F, -40.3148F, -0.8271F, 1F, 34F, 2F, new CubeDeformation(0F, 0F, 0F)).texOffs(14, 38).mirror(false).addBox(-0.5F, -5.3148F, -0.8271F, 1F, 12F, 2F, new CubeDeformation(0F, 0F, 0F)).texOffs(31, 0).mirror(false).addBox(-1.5F, -6.3148F, -1.8271F, 3F, 1F, 4F, new CubeDeformation(0F, 0F, 0F)).texOffs(0, 0).mirror(false).addBox(-0.5F, -41.3148F, 0.1729F, 1F, 1F, 1F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(-6.5F, -1.3204F, -18.6279F, 1.3788F, 0F, -3.1416F));
        PartDefinition b_left_arm = b_body.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(14, 44).mirror(false).addBox(-0.5F, -1.5F, -4F, 5F, 19F, 8F, new CubeDeformation(0.5F, 0.5F, 0.5F)), PartPose.offset(8.5F, -12.5F, 0F));
        PartDefinition b_sword = b_left_arm.addOrReplaceChild("sword", CubeListBuilder.create().texOffs(14, 71).mirror(false).addBox(-0.5F, -40.3148F, -0.8272F, 1F, 34F, 2F, new CubeDeformation(0F, 0F, 0F)).texOffs(14, 38).mirror(false).addBox(-0.5F, -5.3148F, -0.8272F, 1F, 12F, 2F, new CubeDeformation(0F, 0F, 0F)).texOffs(31, 0).mirror(false).addBox(-1.5F, -6.3148F, -1.8271F, 3F, 1F, 4F, new CubeDeformation(0F, 0F, 0F)), PartPose.offsetAndRotation(1F, 15.6796F, 0.4721F, -1.3963F, 0F, 0F));
        PartDefinition b_right_arm = b_body.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(40, 52).mirror(false).addBox(-4.5F, -1.5F, -4F, 5F, 19F, 8F, new CubeDeformation(0.5F, 0.5F, 0.5F)), PartPose.offset(-8.5F, -12.5F, 0F));
        PartDefinition b_head = b_body.addOrReplaceChild("head", CubeListBuilder.create().texOffs(66, 67).mirror(false).addBox(-4F, -8.25F, -3.375F, 8F, 8F, 8F, new CubeDeformation(0F, 0F, 0F)).texOffs(62, 30).mirror(false).addBox(-4F, -12.25F, -3.375F, 8F, 6F, 2F, new CubeDeformation(0.5F, 0.5F, 0.5F)).texOffs(68, 9).mirror(false).addBox(-4F, -8.25F, -3.375F, 8F, 8F, 8F, new CubeDeformation(0.25F, 0.25F, 0.25F)).texOffs(38, 17).mirror(false).addBox(-5F, -4.25F, -3.375F, 10F, 4F, 9F, new CubeDeformation(0.2F, 0.2F, 0.2F)), PartPose.offset(0F, -14.75F, -0.625F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    public static LayerDefinition willagerTarget() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition b_bb_main = root.addOrReplaceChild("bb_main", CubeListBuilder.create().texOffs(0, 0).mirror(false).addBox(-10F, -0F, -10F, 20F, 0F, 20F, new CubeDeformation(0F, 0F, 0F)), PartPose.offset(0F, 24F, 0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

}