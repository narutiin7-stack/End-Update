package br.theendupdate.bosses.client;

import br.theendupdate.bosses.entity.BossMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;

/**
 * Animacoes procedurais (o Bedrock usa animacoes Molang, que nao existem no Java). Cobrem: olhar, andar, braços
 * levantados ao atacar, asas batendo (Flender), giro do corpo (Samurai).
 * Se algum osso estiver torto ou invertido, os sinais/eixos sao ajustados AQUI.
 */
final class BossAnimators {
    private BossAnimators() {}

    private static int state(Entity e) { return e instanceof BossMob b ? b.getState() : 0; }

    static <T extends Mob> void humanoid(BossModel<T> m, T e, float swing, float amount, float age, float yaw, float pitch) {
        BossModel.look(m.bone("head"), yaw, pitch);
        BossModel.walk(m.bone("leg0"), m.bone("leg1"), swing, amount);
        var arms = m.bone("arms");
        if (state(e) != 0 && arms != null) arms.xRot = -0.9F + (float) Math.sin(age * 0.3F) * 0.15F;     // conjurando
        var ra = m.bone("rightarm"); var la = m.bone("leftarm");
        if (state(e) != 0) { if (ra != null) ra.xRot = -1.6F; if (la != null) la.xRot = -1.6F; }
        else { if (ra != null) ra.xRot = (float) Math.cos(swing * 0.6662F + Math.PI) * 0.8F * amount; if (la != null) la.xRot = (float) Math.cos(swing * 0.6662F) * 0.8F * amount; }
    }

    static <T extends Mob> void flender(BossModel<T> m, T e, float swing, float amount, float age, float yaw, float pitch) {
        BossModel.look(m.bone("Head"), yaw, pitch);
        float flap = (float) Math.sin(age * 0.35F) * 0.45F;
        var w2 = m.bone("Wings2"); var w3 = m.bone("Wings3");
        if (w2 != null) w2.zRot = flap; if (w3 != null) w3.zRot = -flap;
        var tail = m.bone("Tail"); if (tail != null) tail.xRot = (float) Math.sin(age * 0.2F) * 0.15F;
    }

    static <T extends Mob> void pyroclast(BossModel<T> m, T e, float swing, float amount, float age, float yaw, float pitch) {
        BossModel.look(m.bone("head"), yaw, pitch);
        var body = m.bone("bone"); if (body != null) body.yRot = state(e) == 3 ? age * 0.5F : 0;           // aura de fogo: gira
        var b2 = m.bone("bone2"); var b3 = m.bone("bone3");
        BossModel.walk(b2, b3, swing, amount);
    }

    static <T extends Mob> void samurai(BossModel<T> m, T e, float swing, float amount, float age, float yaw, float pitch) {
        BossModel.look(m.bone("head"), yaw, pitch);
        var body = m.bone("body");
        if (body != null && state(e) == 1) body.yRot = age * 0.9F;                                          // giro
        var ra = m.bone("right_arm"); var la = m.bone("left_arm");
        if (state(e) == 1 || state(e) == 0) {
            if (ra != null) ra.xRot = (float) Math.cos(swing * 0.6662F) * 0.8F * amount - (state(e) == 1 ? 1.2F : 0F);
            if (la != null) la.xRot = (float) Math.cos(swing * 0.6662F + Math.PI) * 0.8F * amount;
        } else if (ra != null) ra.xRot = -1.8F;
    }
}
