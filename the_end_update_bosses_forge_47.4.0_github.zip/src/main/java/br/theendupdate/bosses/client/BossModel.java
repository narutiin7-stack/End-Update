package br.theendupdate.bosses.client;

import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.Entity;

/** Modelo generico: acha qualquer osso pelo nome (caminho gerado em BossBonePaths) e delega a animacao. */
public class BossModel<T extends Entity> extends HierarchicalModel<T> {
    public interface Animator<T extends Entity> {
        void animate(BossModel<T> m, T e, float limbSwing, float limbSwingAmount, float age, float headYaw, float headPitch);
    }

    private final ModelPart root;
    private final String[][] paths;
    private final Animator<T> animator;

    public BossModel(ModelPart root, String[][] paths, Animator<T> animator) {
        this.root = root; this.paths = paths; this.animator = animator;
    }

    @Override public ModelPart root() { return root; }

    /** Osso pelo nome, ou null se nao existir. */
    public ModelPart bone(String name) {
        for (String[] p : paths) {
            if (p[p.length - 1].equals(name)) {
                ModelPart part = root;
                for (String s : p) part = part.getChild(s);
                return part;
            }
        }
        return null;
    }

    @Override
    public void setupAnim(T e, float limbSwing, float limbSwingAmount, float age, float headYaw, float headPitch) {
        root.getAllParts().forEach(ModelPart::resetPose);
        animator.animate(this, e, limbSwing, limbSwingAmount, age, headYaw, headPitch);
    }

    public static void look(ModelPart head, float yaw, float pitch) {
        if (head == null) return;
        head.yRot = yaw * ((float) Math.PI / 180F);
        head.xRot = pitch * ((float) Math.PI / 180F);
    }

    public static void walk(ModelPart a, ModelPart b, float swing, float amount) {
        if (a != null) a.xRot = (float) Math.cos(swing * 0.6662F) * 1.4F * amount;
        if (b != null) b.xRot = (float) Math.cos(swing * 0.6662F + Math.PI) * 1.4F * amount;
    }
}
