package br.theendupdate.bosses.client;

import br.theendupdate.bosses.EndUpdateBosses;
import br.theendupdate.bosses.entity.*;
import br.theendupdate.bosses.registry.ModEntities;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Registra camadas de modelo e renderizadores (somente cliente). */
@Mod.EventBusSubscriber(modid = EndUpdateBosses.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {}

    static ModelLayerLocation layer(String n) { return new ModelLayerLocation(new ResourceLocation(EndUpdateBosses.MODID, n), "main"); }
    static ResourceLocation tex(String n) { return new ResourceLocation(EndUpdateBosses.MODID, "textures/entity/" + n + ".png"); }

    public static final ModelLayerLocation WILLAGER = layer("willager"), ENCHANTAEGIS = layer("enchantaegis"), FLENDER = layer("flender"),
            PYROCLAST = layer("shielded_pyroclast"), SAMURAI = layer("withered_samurai");

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(WILLAGER, BossModelDefs::willager);
        e.registerLayerDefinition(ENCHANTAEGIS, BossModelDefs::enchantaegis);
        e.registerLayerDefinition(FLENDER, BossModelDefs::flender);
        e.registerLayerDefinition(PYROCLAST, BossModelDefs::pyroclast);
        e.registerLayerDefinition(SAMURAI, BossModelDefs::samurai);
    }

    /** Renderizador simples: modelo + textura + escala. */
    static class R<T extends Mob> extends MobRenderer<T, BossModel<T>> {
        private final ResourceLocation texture; private final float scale;
        R(Context c, BossModel<T> m, String tex, float shadow, float scale) { super(c, m, shadow); this.texture = tex(tex); this.scale = scale; }
        @Override public ResourceLocation getTextureLocation(T e) { return texture; }
        @Override protected void scale(T e, PoseStack ps, float pt) { ps.scale(scale, scale, scale); }
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.WILLAGER.get(), c -> new R<WillagerBoss>(c, new BossModel<>(c.bakeLayer(WILLAGER), BossBonePaths.WILLAGER, BossAnimators::humanoid), "willager", 0.7F, 1.5F));
        e.registerEntityRenderer(ModEntities.WILLAGER_CLONE.get(), c -> new R<WillagerClone>(c, new BossModel<>(c.bakeLayer(WILLAGER), BossBonePaths.WILLAGER, BossAnimators::humanoid), "willager", 0.3F, 1.5F));
        e.registerEntityRenderer(ModEntities.ENCHANTAEGIS.get(), c -> new R<EnchantaegisBoss>(c, new BossModel<>(c.bakeLayer(ENCHANTAEGIS), BossBonePaths.ENCHANTAEGIS, BossAnimators::humanoid), "enchantaegis", 0.6F, 1.0F));
        e.registerEntityRenderer(ModEntities.FLENDER.get(), c -> new R<FlenderBoss>(c, new BossModel<>(c.bakeLayer(FLENDER), BossBonePaths.FLENDER, BossAnimators::flender), "flender", 1.0F, 1.0F));
        e.registerEntityRenderer(ModEntities.SHIELDED_PYROCLAST.get(), c -> new R<PyroclastBoss>(c, new BossModel<>(c.bakeLayer(PYROCLAST), BossBonePaths.PYROCLAST, BossAnimators::pyroclast), "shielded_pyroclast", 0.9F, 1.0F));
        e.registerEntityRenderer(ModEntities.WITHERED_SAMURAI.get(), c -> new R<SamuraiBoss>(c, new BossModel<>(c.bakeLayer(SAMURAI), BossBonePaths.SAMURAI, BossAnimators::samurai), "withered_samurai", 0.9F, 1.0F));
        e.registerEntityRenderer(ModEntities.BOSS_PROJECTILE.get(), ThrownItemRenderer::new);
    }
}
